#!/bin/bash
#SBATCH --time=12:00:00   # walltime in d-hh:mm or hh:mm:ss format
#SBATCH --ntasks=4        # number of MPI processes
#SBATCH --mem-per-cpu=3800
#SBATCH --account=def-someuser
source ~/astro/bin/activate
srun python nested.py
