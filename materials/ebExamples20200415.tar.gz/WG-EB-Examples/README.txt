* For more information about eb: 
--------------------------------

eb --help
eb -H

* To list all easyblocks and Extensions: 
----------------------------------------

eb --list-easyblocks

* To list all easyconfig parameters: 
------------------------------------

eb -a
eb --avail-easyconfig-params

* To list all ToolChains:
-------------------------

eb --list-toolchains

* To list all the programs supported with EB:
---------------------------------------------

eb --list-software

{The command shows about 2100 different programs}.

* To search for a given recipe, use "eb -S <name of the program>":
------------------------------------------------------------------

Examples:

eb -S GSL
eb -S DIAMOND
eb -S Java
eb -S Stata

[cedar1 ~]$  eb -S DALTON
CFGS1=/cvmfs/soft.computecanada.ca/easybuild/easyconfigs/d/DALTON
CFGS2=/cvmfs/soft.computecanada.ca/easybuild/ebfiles_repo/DALTON
 * $CFGS1/DALTON-2017-alpha-iomkl-2016.4.11.eb
 * $CFGS1/DALTON-2017-alpha-iomkl-2016.4.eb
 * $CFGS1/DALTON-2018-iomkl-2016.4.11.eb
 * $CFGS1/DALTON-2018-iomkl-2018.3.312.eb
 * $CFGS2/DALTON-2017-alpha-iomkl-2016.4.eb
 * $CFGS2/DALTON-2017-alpha-iomkl-2018.3.312.eb
 * $CFGS2/DALTON-2018-iomkl-2018.3.312.eb

* To install a software using an existing recipe, use:
------------------------------------------------------

eb <recipe> <+options>

Most used options:

  * Switch the Toolchain: 
       --try-toolchain=<another toolchain>
  * Switch the software version: 
       --try-software-version=<another version>
  * Build with threads (1, ... ): 
       --parallel = 8
  * Force the build (if the module is already installed): 
       --force or --rebuild
  * Build the program and its missing dependencies: 
       --robot
  * Build the code without providing checksums: 
       --disable-enforce-checksums
  * Custom path for the module: 
       --installpath-modules=${}
  * Custom path for the installation directory: 
       --installpath-software=${}
  * Custom path for the installation directory: 
       --prefix=${install-dir}
  * Path to the location of the source files: 
       --sourcepath=${path to src}

These options change the recipe but do not build the program:
 
  * To add checksums with EasyBuild: 
       --inject-checksums
  * To fix old easyconfigs (example: name of variables should start with local_):
       --fix-deprecated-easyconfigs

==============
Some Examples:
==============

Installing GSL:
---------------

2. Installing GSL 2.4 with GCC-5.5.0 and GCC-7.3.0 toolchains:

* Ignore the checksums:

eb GSL-2.4-GCC-5.4.0.eb --force --disable-enforce-checksums
eb GSL-2.4-GCC-5.4.0.eb --rebuild --disable-enforce-checksums

* Inject the checksums paramter:

$  eb GSL-2.4-GCC-5.4.0.eb --inject-checksums
== temporary log file in case of crash /tmp/eb-6oKz1H/easybuild-1J687v.log
== Running parse hook for GSL-2.4-GCC-5.4.0.eb...
== Running parse hook for GCC-7.3.0.eb...
== Running parse hook for GCCcore-7.3.0.eb...
== Running parse hook for GCC-7.3.0.eb...
== injecting sha256 checksums in /home/kerrache/WG/GSL-2.4-GCC-5.4.0.eb
== fetching sources & patches for GSL-2.4-GCC-5.4.0.eb...
== backup of easyconfig file saved to /home/kerrache/WG/GSL-2.4-GCC-5.4.0.eb.bak_20200413165448_23531...
== injecting sha256 checksums for sources & patches in GSL-2.4-GCC-5.4.0.eb...
== * gsl-2.4.tar.gz: 4d46d07b946e7b31c19bbf33dda6204d7bedc2f5462a1bae1d4013426cd1ce9b
== Temporary log file(s) /tmp/eb-6oKz1H/easybuild-1J687v.log* have been removed.
== Temporary directory /tmp/eb-6oKz1H has been removed.


* Install GSL:
 
eb GSL-2.4-GCC-5.4.0.eb --force

* Install GSL 2.4 with GCC-7.3.0 toolchain:

eb GSL-2.4-GCC-5.4.0.eb --force --try-toolchain=GCC,7.3.0

* Install GSL 2.5 with GCC-5.4.0 and GCC-7.3.0 toolchain:

eb GSL-2.4-GCC-5.4.0.eb --try-software-version=2.5 --force --disable-enforce-checksums

eb GSL-2.4-GCC-5.4.0.eb --try-toolchain=iccifort,2016.4 --force

eb GSL-2.4-GCC-5.4.0.eb --try-toolchain=iccifort,2018.3 --force

Installing ADMIXTURE:
---------------------

eb ADMIXTURE-1.3.0.eb --rebuild
eb ADMIXTURE-1.3.0.eb --force

Installing RAxML:
-----------------

eb RAxML-8.2.11-gompi-2016.4.11.eb --force
eb RAxML-8.2.11-gompi-2016.4.11.eb --force --try-toolchain=iompi,2016.4.11
eb RAxML-8.2.11-gompi-2016.4.11.eb --try-toolchain=iompi,2018.3.312 --force

Installing DIAMOND:
-------------------

eb --rebuild DIAMOND-0.8.36-GCC-5.4.0.eb --force
eb --rebuild DIAMOND-0.8.36-GCC-5.4.0.eb --try-software-version=0.9.22 --disable-enforce-checksums
eb --rebuild DIAMOND-0.8.36-GCC-5.4.0.eb --try-toolchain=GCC,7.3.0

Installing FastTree:
--------------------

eb --rebuild FastTree-2.1.10-GCC-5.4.0.eb
eb --rebuild FastTree-2.1.10-GCC-5.4.0.eb --try-toolchain=GCC,9.1.0

Installing fastStructure:
-------------------------

eb fastStructure-1.0-GCC-5.4.0.eb --force
eb fastStructure-1.0-GCC-5.4.0.eb --force --try-toolchain=GCC,9.1.0 --robot --disable-enforce-checksums

Installing BLAST+:
------------------

eb --rebuild BLAST+-2.10.0-GCC-7.3.0.eb 

Installing Siesta:
------------------

eb Siesta-4.1-b2-iomkl-2016.4.11.eb --force
eb Siesta-4.1-b2-iomkl-2016.4.11.eb --force --try-toolchain=iomkl,2018.3.312

Installing DALTON:
------------------

eb --rebuild DALTON-2018-iomkl-2016.4.11.eb
eb --rebuild DALTON-2018-iomkl-2016.4.11.eb  --try-toolchain=gomkl,2016.4.11

Installing StringTie:
---------------------

eb StringTie-2.1.0-GCC-7.3.0.eb --force
eb StringTie-2.1.0-GCC-7.3.0.eb --try-toolchain=GCC,9.1.0

Installing PfamScan:
--------------------

eb PfamScan-1.6-GCC-7.3.0.eb --force --disable-enforce-checksums
eb PfamScan-1.6-GCC-7.3.0.eb --force --disable-enforce-checksums --try-toolchain=GCC,9.1.0 --robot

Installing Zlib:
----------------

eb zlib-1.2.11-GCC-5.4.0.eb
eb zlib-1.2.11-GCC-5.4.0.eb --try-toolchain=iccifort,2016.4
eb zlib-1.2.11-GCC-5.4.0.eb --try-toolchain=GCC,8.3.0

Installing Stata:
-----------------

eb Stata-15.eb 

{It requires a license to download the source files.}


Installing Circos:
------------------

eb Circos-0.69-6.eb --force

