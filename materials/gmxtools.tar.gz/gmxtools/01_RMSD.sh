#!/bin/bash

#SBATCH --output=slurm_RMSD.out

module purge
module load StdEnv/2020 gcc/9.3.0 openmpi/4.0.3
module load gromacs/2022.3

simdir="../../simulations/2_MD"

srun gmx rms -s $simdir/topol.tpr -f $simdir/traj_comp.xtc \
	-o Anx_backbone_RMSD_fit_to_Ca.xvg -e 5 -tu ns
