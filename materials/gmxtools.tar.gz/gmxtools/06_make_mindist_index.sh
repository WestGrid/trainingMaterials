#!/bin/bash

module purge
module load StdEnv/2020 gcc/9.3.0 openmpi/4.0.3
module load gromacs/2022.3

simdir="../../simulations/2_MD"

gmx select -s $simdir/topol.tpr -on groups.ndx <<-EOF
		"Bilayer" resname DOPC and name P
		"Anx-12"  group Protein and resid 12
		"Anx-16"  group Protein and resid 16
		"Anx-104" group Protein and resid 104
		"Anx-112" group Protein and resid 112
		"Anx-117" group Protein and resid 117
		"Anx-121" group Protein and resid 121
		"Anx-124" group Protein and resid 124
		"Anx-128" group Protein and resid 128
		"Anx-137" group Protein and resid 137
		"Anx-141" group Protein and resid 141
		"Anx-144" group Protein and resid 144
		"Anx-162" group Protein and resid 162
		"Anx-180" group Protein and resid 180
		"Anx-260" group Protein and resid 260
	EOF
