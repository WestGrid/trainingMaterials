#!/bin/bash

#SBATCH --output=slurm_mindist.out

module purge
module load StdEnv/2020 gcc/9.3.0 openmpi/4.0.3
module load gromacs/2022.3

simdir="../../simulations/2_MD"

resids="12 16 104 112 117 121 124 128 137 141 144 162 180 260"

for i in $resids; do
	srun gmx mindist -s $simdir/topol.tpr -f $simdir/traj_comp.xtc \
		-n groups.ndx -od distance_${i}.xvg -b 10 -e 20 -tu ns <<-EOF
			Bilayer
			Anx-$i
		EOF
done
