#!/bin/bash

# WARNING: This script is only meant as an example. Do not submit multiple
# jobs using loops as in done here. Doing so can degrade scheduler performance.
# Use job arrays instead.

resids="12 16 104 112 117 121 124 128 137 141 144 162 180 260"

for i in $resids; do
	sbatch mindist.sh $i
	sleep 1
done
