#!/bin/bash

#SBATCH --output=slurm_mindist_%j.out

module purge
module load StdEnv/2020 gcc/9.3.0 openmpi/4.0.3
module load gromacs/2022.3

simdir="../../simulations/2_MD"

i=$1

srun gmx mindist -s $simdir/topol.tpr -f $simdir/traj_comp.xtc \
	-n groups.ndx -od distance_${i}.xvg -b 10 -e 20 -tu ns <<-EOF
		Bilayer
		Anx-$i
	EOF
