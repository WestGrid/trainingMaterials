#!/bin/bash

resids="12 16 104 112 117 121 124 128 137 141 144 162 180 260"
trjids="01 02 03 04 05 06 07 08 09 10"

rm -f MSD_vars.txt

for i in $resids; do
	for j in $trjids; do
		echo $i $j >> MSD_vars.txt
	done
done
