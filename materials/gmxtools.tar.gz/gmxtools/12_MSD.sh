#!/bin/bash

#SBATCH --array=1-140

set -e

module purge
module load StdEnv/2020 gcc/9.3.0 openmpi/4.0.3
module load gromacs/2021.4

lineno=$SLURM_ARRAY_TASK_ID
read i j <<< $(sed "${lineno}q;d" MSD_vars.txt)

simroot="../../simulations"
simdir="$simroot/3.${j}_short_relaxation"

gmx select -s $simdir/topol.tpr -on groups_${i}_${j}.ndx <<-EOF
	"Shell" group Water and within 0.5 of (group Protein and resid $i)
EOF
srun gmx msd -s $simdir/topol.tpr -f $simdir/traj_comp.xtc \
	-n groups_${i}_${j}.ndx -o msd_${i}_${j}.xvg -e 10 -trestart 10
