#!/bin/bash

#SBATCH --cpus-per-task=40
#SBATCH --output=slurm_MSD.out

resids="12 16 104 112 117 121 124 128 137 141 144 162 180 260"
trjids="01 02 03 04 05 06 07 08 09 10"

parallel bash MSD.sh {1} {2} ::: $resids ::: $trjids
