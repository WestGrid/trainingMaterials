#!/bin/bash

set -e

module purge
module load StdEnv/2020 gcc/9.3.0 openmpi/4.0.3
module load gromacs/2021.4

i=$1
j=$2

simroot="../../simulations"
simdir="$simroot/3.${j}_short_relaxation"

gmx select -s $simdir/topol.tpr -on groups_${i}_${j}.ndx <<-EOF
		"Shell" group Water and within 0.5 of (group Protein and resid $i)
	EOF
gmx msd -s $simdir/topol.tpr -f $simdir/traj_comp.xtc \
	-n groups_${i}_${j}.ndx -o msd_${i}_${j}.xvg -e 10 -trestart 11
