#!/bin/bash

#SBATCH --output=slurm_extract_protein.out

module purge
module load StdEnv/2020 gcc/9.3.0 openmpi/4.0.3
module load gromacs/2022.3

simdir="../../simulations/2_MD"

srun gmx trjconv -s $simdir/topol.tpr -f $simdir/traj_comp.xtc \
	-o traj_protein.trr -e 5 -tu ns <<-EOF
		Protein
	EOF
