#!/bin/bash

#SBATCH --output=slurm_RMSD.out

module purge
module load StdEnv/2020 gcc/9.3.0 openmpi/4.0.3
module load gromacs/2022.3

simdir="../../simulations/2_MD"

time srun gmx rms -s $simdir/topol.tpr -f $simdir/traj_comp.xtc \
	-o Anx_backbone_RMSD_fit_to_Ca_1.xvg -e 5 -tu ns <<-EOF
		C-alpha
		Backbone
	EOF

time srun gmx rms -s $simdir/topol.tpr -f traj_protein.trr \
	-o Anx_backbone_RMSD_fit_to_Ca_2.xvg -e 5 -tu ns <<-EOF
		C-alpha
		Backbone
	EOF
