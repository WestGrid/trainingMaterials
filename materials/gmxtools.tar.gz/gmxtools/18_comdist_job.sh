#!/bin/bash

#SBATCH --output=slurm_comdist.out

module purge
module load python/3.8.10

source $HOME/MDA_env/bin/activate

srun python comdist.py
