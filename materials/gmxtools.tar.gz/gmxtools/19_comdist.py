from os import path
import numpy as np
import MDAnalysis as mda

simdir = "../../simulations/2_MD"
gro = path.join(simdir, "confout.gro")
xtc = path.join(simdir, "traj_comp.xtc")

u = mda.Universe(gro, xtc)
natoms = len(u.atoms)
nframes = len(u.trajectory)

print(f"Loaded {natoms}-atom structure")
print(f"Loaded {nframes}-frame trajectory")

resids = [12, 16, 104, 112, 117, 121, 124, 128, 137, 141, 144]

upper_bilayer_P = u.select_atoms("resname DOPC and name P and prop z > 40.0")
Anx_probes = [u.select_atoms(f"protein and resid {i}") for i in resids]

outfile = open("bilayer_distances.dat", "w")

for frame in u.trajectory:
    if frame.time > 10 * 1000:
        break
    outfile.write(f"{frame.time:8}")
    Zbilayer = upper_bilayer_P.center_of_mass()[2]
    for probe in Anx_probes:
        dZ = probe.center_of_mass()[2] - Zbilayer
        outfile.write(f" {dZ:5.1f}")
    outfile.write("\n")
