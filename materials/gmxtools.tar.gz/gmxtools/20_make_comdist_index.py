from os import path
import numpy as np
import MDAnalysis as mda

simdir = "../../simulations/2_MD"
gro = path.join(simdir, "confout.gro")

u = mda.Universe(gro)
natoms = len(u.atoms)

print(f"Loaded {natoms}-atom structure")

resids = [12, 16, 104, 112, 117, 121, 124, 128, 137, 141, 144]

upper_bilayer_P = u.select_atoms("resname DOPC and name P and prop z > 40.0")
upper_bilayer_P.write("groups.ndx", name="UpperBilayer")

for i in resids:
    Anx_probe = u.select_atoms(f"protein and resid {i}")
    Anx_probe.write("groups.ndx", name=f"Anx-{i}", mode="a")
