p = exp(-(inputs[0].Points[:,0]**2+inputs[0].Points[:,1]**2)/(2*0.02))

---

print(type(output))   # paraview.vtk.numpy_interface.dataset_adapter.PolyData
print(dir(output))
print(output.Points.shape)   # actually a 3D dataset
print(output.Points)         # but all z-coordinates are 0s

---

output.Points[:,2] = 0.5*inputs[0].PointData["p"]   # set the output's z-axis
dataArray = 0.3 + inputs[0].PointData["p"]
output.PointData.append(dataArray, "pnew")       # add the new data array to our output

---

print(output.PointData["pnew"].shape)

---

print(output.PointData["pnew"])
print(output.GetPointData().GetArray("pnew"))

---

print(output.GetNumberOfPoints())
print(output.GetPoint(1005))
print(output.Points[1005,:])

---

output.Points[:,2] = 0.5*exp(-(inputs[0].Points[:,0]**2+
                               inputs[0].Points[:,1]**2)/(2*0.02))
dataArray = 0.3 + 2*output.Points[:,2]
output.PointData.append(dataArray, "pnew")   # add the new data array to our output
