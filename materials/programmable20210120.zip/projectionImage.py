# Programmable Filter
# vtkImageData
# output = self.GetOutput()
# ------
numPoints = inputs[0].GetNumberOfPoints()
side = round(numPoints**(1./3.))
layer = side*side
rho = inputs[0].PointData['density']
           # also inputs[0].GetPointData().GetArray('density')

output.SetOrigin(inputs[0].GetPoint(0)[0],
                 inputs[0].GetPoint(0)[1], -20.)
output.SetSpacing(1.0, 1.0, 1.0)
output.SetDimensions(side, side, 1)
output.SetExtent(0,99,0,99,0,1)
output.AllocateScalars(vtk.VTK_FLOAT, 1)

rho3D = rho.reshape(side, side, side)
vtk_data_array = vtk.util.numpy_support.
          numpy_to_vtk(rho3D.sum(axis=2).ravel(),
                       deep=True, array_type=vtk.VTK_FLOAT)
vtk_data_array.SetNumberOfComponents(1)
vtk_data_array.SetName("projection")
output.GetPointData().SetScalars(vtk_data_array)

------
from paraview import util
n = 100
util.SetOutputWholeExtent(self,
               [0,n-1,0,n-1,0,0])
