# Programmable Source
# vtkTable
# ------
import numpy as np
data = np.genfromtxt("/Users/razoumov/Documents/01-webinar/tabulatedGrid.txt",
                     dtype=None, names=True, delimiter=',', autostrip=True)
for name in data.dtype.names:   # go through all 4 columns
   array = data[name]           # this is a numpy array
   output.RowData.append(array, name)
