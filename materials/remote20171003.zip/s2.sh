#!/bin/bash
#SBATCH --time=00:15:00   # give it a little bit more time
#SBATCH --job-name="quick test"
#SBATCH --mem=2000    # in MB
#SBATCH --account=def-razoumov-ac
pvbatch --use-offscreen-rendering spin.py
