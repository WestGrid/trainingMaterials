import matplotlib as mpl
mpl.use('Agg')     # for PNG; could also use PS or PDF backends
import matplotlib.pyplot as plt
from numpy import *
x = linspace (0 ,3)
y = 10.*exp(-2.*x)
plt.figure(figsize=(10,8))
plt.plot(x, y, 'ro-')
plt.savefig('tmp.png')
