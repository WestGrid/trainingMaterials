#!/bin/bash
#SBATCH --time=12:00:00   # walltime in d-hh:mm or hh:mm:ss format
#SBATCH --ntasks=4        # number of MPI processes
#SBATCH --mem-per-cpu=3600
#SBATCH --account=def-someuser
module load mpi4py        # important to load this before next line
source ~/astro/bin/activate
srun python grids.py
