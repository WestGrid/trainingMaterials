#!/bin/bash
#SBATCH --ntasks=1                    # Number of cores/tasks
#SBATCH --nodes=1                     # Number of nodes, ensure that all cores are on one machine
#SBATCH --time=0-00:02                # Runtime in D-HH:MM
#SBATCH --array=1-4                   # 
#SBATCH -o slurm-input-array-%a.out   # File to which STDOUT will be written
#SBATCH --job-name=my-input-array-job # 
#SBATCH --mail-type=all               # Type of email notification- BEGIN,END,FAIL,ALL
#SBATCH --mail-user=no.email@ubc.ca   # Email to which notifications will be sent
##                   ^
##                   |
##                   --- Replace the above email address with to your own

LINE=`(cat input.array | head -$SLURM_ARRAY_TASK_ID | tail -1)`
F1=`echo $LINE |cut -d " " -f1`
F2=`echo $LINE |cut -d " " -f2`

# Generate some output
# This is were you would run your simulation
# We will double the first number and add it to the second
#   In real life this line would be replaced with whatever simulation you need to run
OUT=`(echo "$F1 * 2 +$F2" | bc)`


echo "ArrayId:$SLURM_ARRAY_TASK_ID"
echo "Line of input numbers is: $LINE"
echo "The 1st field of the line is:$F1"
echo "The 2nd field of the line is:$F2"
echo "The output of multiplying the first by 2 number and adding the second is:$OUT"
