#!/bin/bash
#SBATCH --ntasks=1                    # Number of cores/tasks
#SBATCH --nodes=1                     # Number of nodes, ensure that all cores are on one machine
#SBATCH --time=0-00:02                # Runtime in D-HH:MM
#SBATCH -o slurm-q3-%j.out            # File to which STDOUT will be written
#SBATCH -e slurm-q3-%j.err            # File to which STDERR will be written
#SBATCH --mail-type=ALL               # Type of email notification- BEGIN,END,FAIL,ALL
#SBATCH --mail-user=no.email@ubc.ca   # Email to which notifications will be sent
##                   ^
##                   |
##                   --- Replace the above email address with to your own
hello
sleep 30
