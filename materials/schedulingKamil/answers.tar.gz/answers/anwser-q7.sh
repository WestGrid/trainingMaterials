#!/bin/bash
#SBATCH --ntasks=1                    # Number of cores/tasks
#SBATCH --nodes=1                     # Number of nodes, ensure that all cores are on one machine
#SBATCH --time=0-00:02                # Runtime in D-HH:MM
#SBATCH --job-name=my-array-job       # Sets the Jobs name
#SBATCH --array=1-12                  # Ask for an Job array of 12 tasks
#SBATCH -o slurm-q7_%j_%a.out         # File to which STDOUT will be written
#SBATCH -e slurm-q7_%j_%a.err         # File to which STDERR will be written
#SBATCH --mail-type=END               # Type of email notification- BEGIN,END,FAIL,ALL
#SBATCH --account=def-kamil
#SBATCH --mail-user=kamil@ualberta.ca # Email to which notifications will be sent
sleep 30
hostname
