#!/bin/bash
#SBATCH --ntasks=1                    # Number of cores/tasks
#SBATCH --nodes=1                     # Number of nodes, ensure that all cores are on one machine
#SBATCH --time=0-00:02                # Runtime in D-HH:MM
#SBATCH --job-name=my-array-job3      # Sets the Jobs name
#SBATCH --array=1,2,7,13              # array with 4 tasks with indexes:1,2,7,13
#SBATCH -o slurm-q9_%j_%a.out         # File to which STDOUT will be written
#SBATCH -e slurm-q9_%j_%a.err         # File to which STDERR will be written
#SBATCH --mail-type=END               # Type of email notification- BEGIN,END,FAIL,ALL
#SBATCH --mail-user=no.email@ubc.ca   # Email to which notifications will be sent
##                   ^
##                   |
##                   --- Replace the above email address with to your own
hostname
echo "This jobs name is:    $SLURM_JOB_NAME"         
echo "This jobs jobid is:    $SLURM_JOB_ID"          
echo "This jobs arrayid is:  $SLURM_ARRAY_TASK_ID"   
echo "This jobs is running on host:  `hostname`"
sleep 30
