#!/bin/bash
#SBATCH --ntasks=1                    # Number of cores/tasks
#SBATCH --nodes=1                     # Number of nodes, ensure that all cores are on one machine
#SBATCH --time=0-00:10                # Runtime in D-HH:MM
#SBATCH --job-name=my-mpi-job1        # Sets the jobs name
#SBATCH -o slurm-q12-%j.out           # File to which STDOUT will be written
#SBATCH --mail-type=ALL               # Type of email notification- BEGIN,END,FAIL,ALL
#SBATCH --mail-user=no.email@ubc.ca   # Email to which notifications will be sent
##                   ^
##                   |
##                   --- Replace the above email address with to your own
module load openmpi/intel/64/1.8.5
module load cuda70/toolkit/7.0.28
hostname
time mpiexec ./mpisample

